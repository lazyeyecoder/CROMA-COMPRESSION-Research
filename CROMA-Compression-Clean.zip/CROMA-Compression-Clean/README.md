# CROMA Compression Research — Reproduction Guide

Run scripts in this order:
1. `01_download.py` — downloads DFC2020 + Canadian Cropland from HF
2. `02a_extract_features_subset.py` → `02_baseline_eval_subset.py` — subset (2000/1000) baseline
3. `02c_extract_features_full.py` → `02b_train_probe_full.py` — full-dataset (46152/8874) baseline
4. `00_fp32_latency_subset.py` / `00_fp32_latency_full.py` — latency benchmarks
5. `03e_dynamic_quant_subset.py` / `03f_dynamic_quant_full.py` — quantization
6. `04_soft_prune_subset.py` / `04_soft_prune_full.py` — naive pruning (ablation, expect poor results)
7. `04b_structural_prune_subset.py` / `04b_structural_prune_full.py` — structural pruning (main result)
8. `05a_hybrid_subset.py` / `05_hybrid_full.py` — combined pruning+quantization

Note: `02_baseline_eval_subset.py` recomputes CROMA features live rather than loading from the cached feature files — this is intentional, it produces the subset `probe_baseline.pt` used downstream by the subset quant/prune/hybrid scripts.

`archive/` contains abandoned attempts (static PTQ, ONNX export) documented as platform limitations in the report, Chapter 5.3. See `archive/03a_quantize_subset_static.py` for the static PTQ attempt and `archive/03c_onnx_quantize_evaluate.py` for the ONNX attempt.

Results in `results/*.txt` match the final reported table (Chapter 5, Table 3).
